function potencia(){
    var base = document.getElementById("Base").value;
    var potencia = document.getElementById("Potencia").value;
    var resultado = Math.pow(base, potencia)
    document.getElementById("Res").innerText = resultado;
}